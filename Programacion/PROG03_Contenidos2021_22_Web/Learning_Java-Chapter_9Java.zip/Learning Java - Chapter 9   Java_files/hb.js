AvgSI.hb =AvgSI.hb || (function ()
{
    var cookieName = "AVG_WTU_HB2_",
        domain = AvgSI.currDomain,
        featureName = "";

    function inject()
    {
        var dontShowCookie = readCookie(cookieName + domain);
        featureName = (AvgSI.currVer == 1)? "hb": "hbCcs";
        if(dontShowCookie == null)
        {
            injectContent();
        }
    }
    function createCookie(name, value, days)
    {
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            var expires = "; expires=" + date.toGMTString();
        }
        else
        {
            var expires = "";
        }
        document.cookie = name + "=" + value + expires + "; path=/";
    }

    function readCookie(name)
    {
        var nameEQ = name + "=",
            ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++)
        {
            var c = ca[i];
            while (c.charAt(0) == ' ')
                c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    function injectContent()
    {
        var body = document.body,
            hb_div = document.createElement('div'),
            hb_div_wrapper = document.createElement('div'),
            threatName = (featureName == 'hb')? "This website might be vulnerable to the Heartbleed security bug. ": "This site might be vulnerable. Sharing personal information on this site is not advised. ",
            linkText = (featureName == 'hb')? "What should I do?" : "Learn more";

        var css = '#AVG_hb_div_wrapper{z-index:2147483637!important;width:100%!important;height:81px!important;border-top:4px solid #ff9600!important;border-bottom:2px solid #ff9600!important;position:absolute!important;top:0!important;background:#1A1A1A!important;-ms-filter:"alpha(Opacity=90)";filter:alpha(opacity=90);opacity:.9;-webkit-box-shadow:0 0 20px rgba(0,0,0,.35)!important;-moz-box-shadow:0 0 20px rgba(0,0,0,.35)!important;box-shadow:0 0 20px rgba(0,0,0,.35)!important;min-width:1000px!important}#AVG_hb_div{z-index:2147483638!important;text-align:center!important;color:#b2b2b2!important;font-family:Arial,Helvetica Neue,Helvetica,sans-serif!important;width:100%!important;height:75px!important;position:absolute!important;top:4px!important;min-width:1000px!important}#AVG_hb_logo{z-index:2147483638!important;width:69px!important;height:28px!important;background:url(http://toolbar.avg.com/ScriptInjector/heartbleed/images/avg_logo_heartbleed.png) no-repeat!important;display:block!important;position:absolute!important;left:6px!important;top:6px!important}#AVG_hb_text_wrap{font-family: Arial !important;position:relative!important;top:15px!important;display:inline-block!important;zoom:1!important;*display:inline!important;vertical-align:middle!important;color:#b2b2b2!important;font-family:Arial,Helvetica Neue,Helvetica,sans-serif!important;font-size:19px!important}#AVG_hb_risky{width:40px!important;height:49px!important;background:url(http://toolbar.avg.com/ScriptInjector/heartbleed/images/hearbleed_ss_risky.png) no-repeat!important;margin-right:8px!important;display:inline-block!important;zoom:1!important;*display:inline!important;vertical-align:middle!important}#AVG_hb_this_site{font-family: Arial !important; display:inline-block!important;font-size:18px !important;zoom:1!important;*display:inline!important;vertical-align:middle!important}#AVG_hb_learn_more{font-family: Arial !important;color:#4b97ff!important;text-decoration:underline!important;font-size:18px !important;cursor:pointer!important}#AVG_hb_dont_show{font-family: Arial !important;position:absolute!important;top:52px!important;right:9px!important;display:block!important;font-size:12px!important;text-decoration:underline!important;cursor:pointer!important}#AVG_hb_pressX{width:17px!important;height:17px!important;position:absolute!important;background:url(http://toolbar.avg.com/ScriptInjector/heartbleed/images/heartbleed_closeBtn.png) no-repeat;top:9px!important;right:9px!important;display:block!important;cursor:pointer!important}',
            head = document.head || document.getElementsByTagName('head')[0],
            style = document.createElement('style');

        style.type = 'text/css';
        if (style.styleSheet) {
            style.styleSheet.cssText = css;
        } else {
            style.appendChild(document.createTextNode(css));
        }

        head.appendChild(style);


        hb_div_wrapper.id = "AVG_hb_div_wrapper";
        hb_div.id = "AVG_hb_div";
        hb_div.dir = "ltr";
        hb_div.innerHTML = '<span id="AVG_hb_logo"></span>' +
            '<div id="AVG_hb_text_wrap">' +
            '<span id="AVG_hb_risky"></span>' +
            '<span id="AVG_hb_this_site">' + threatName + '<a id="AVG_hb_learn_more" onclick="AvgSI.hb.learnMore()" href="#">' + linkText + '</a></span>' +
            '</div>' +
            '<span id="AVG_hb_dont_show" onclick="AvgSI.hb.dontShowAgain();">Don`t show this again for this site</span>' +
            '<span id="AVG_hb_pressX" onclick="AvgSI.hb.pressX();"></span>';

        body.insertBefore(hb_div, body.firstChild);
        body.insertBefore(hb_div_wrapper, body.firstChild);


        AvgSI.sendActionStats("view", featureName, "wtu");
    }

    function pressX(event)
    {
        event && event.preventDefault();
        AvgSI.sendActionStats("x", featureName, "wtu");
        document.body.removeChild(document.getElementById("AVG_hb_div"));
        document.body.removeChild(document.getElementById("AVG_hb_div_wrapper"));
    }

    function learnMore(event)
    {
        event && event.preventDefault();
        AvgSI.sendActionStats("click", featureName, "wtu");
        //window.open("http://webtuneup.avg.com/hbLearnMore", "_blank");
        var tmpLink = document.createElement('a');
        tmpLink.id="clickedTile";
        tmpLink.style.position="absolute";
        tmpLink.style.left="-9999px";
        tmpLink.style.top="-9999px";
        tmpLink.href= (featureName == 'hb')? "http://blogs.avg.com/news-threats/heartbleed" : "http://blogs.avg.com/news-threats/webservers-still-vulnerable";
        tmpLink.target="_blank";

        document.body.appendChild(tmpLink);
        tmpLink.click();
        document.body.removeChild(tmpLink);
    }

    function dontShowAgain(event)
    {
        event && event.preventDefault();
        AvgSI.sendActionStats("dontShow", featureName, "wtu");
        createCookie(cookieName + domain, "1", "90");
        document.body.removeChild(document.getElementById("AVG_hb_div"));
        document.body.removeChild(document.getElementById("AVG_hb_div_wrapper"));
    }

    return {
        inject: inject,
        pressX: pressX,
        learnMore: learnMore,
        dontShowAgain: dontShowAgain
    };
}());

AvgSI.hb.inject();