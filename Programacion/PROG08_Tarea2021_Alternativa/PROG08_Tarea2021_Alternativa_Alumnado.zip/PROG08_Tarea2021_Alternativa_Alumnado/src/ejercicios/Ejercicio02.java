package ejercicios;

public class Ejercicio02 {

    public static void main(String[] args) {
        
        
    }

}
