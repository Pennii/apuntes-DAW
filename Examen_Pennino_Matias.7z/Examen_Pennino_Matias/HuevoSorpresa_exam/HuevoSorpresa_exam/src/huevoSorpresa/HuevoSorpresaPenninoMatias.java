package huevoSorpresa;
/**
 * Clase que realiza las acciones de un huevo sorpresa
 * @author Matias agustin Pennino
 */
public class HuevoSorpresaPenninoMatias {

    /**
     * metodo que devuelve la cantidad de huevos que quedan
     * @return unidades de huevo
     */
    public int getUnidades() {
        return unidades;
    }

    /**
     * metodo que establece la cantidad de huevos que quedan
     * @param unidades unidades de huevo
     */
    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }

    /**
     * metodo que devuelve el precio del huevo
     * @return precio del huevo
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * metodo que establece el precio del huevo
     * @param precio precio del huevo
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * metodo que devuelve el contenido del huevo
     * @return contenido sorpresa del huevo
     */
    public String getSorpresa() {
        return sorpresa;
    }

    /**
     * metodo que establece el contenido del huevo
     * @param sorpresa contenido sorpresa del huevo
     */
    public void setSorpresa(String sorpresa) {
        this.sorpresa = sorpresa;
    }

    /**
     * devuelve el precio maximo de un huevo
     * @return the precio_max precio maximo de un huevo
     */
    public double getPrecio_max() {
        return precio_max;
    }

    /**
     * metodo que establece el precio maximo de un huevo
     * @param precio_max the precio_max to set precio maximo del huevo
     */
    public void setPrecio_max(double precio_max) {
        this.precio_max = precio_max;
    }
    private int unidades;//número de huevos que quedan 
    private double precio;//precio actual de un huevo sorpresa
    private String sorpresa;//nombre de la sorpresa que incluye huevo sorpresa
    private double precio_max;//precio máximo que puede tener un huevo sorpresa
    
    
    /**
     * constructor sin parametros
     */
public HuevoSorpresaPenninoMatias(){}


/**
 * constructor de 4 parametros
 * @param unidades unidades de huevo
 * @param precio precio de un huevo
 * @param sorpresa contenido del huevo
 * @param precio_max precio maximo de un huevo
 */
public HuevoSorpresaPenninoMatias(int unidades, double precio, String sorpresa, double precio_max){
    this.unidades=unidades;
    this.precio=precio;
    this.sorpresa=sorpresa;
    this.precio_max=precio_max;
}


/**
 * metodo que devuelve la cantidad de huevos que quedan
 * @return cantidad de huevos que quedan
 */
public int obtenerUnidades(){return this.getUnidades();}


/**
 * metodo que devuelve el precio de un huevo
 * @return precio del huevo
 */
public double obtenerPrecio(){return this.getPrecio();}


/**
 * metodo que modifica las unidades de un huevo
 * @param unidades cantidad de huevos
 */
public void modificarUnidades(int unidades){this.setUnidades(unidades);}

/**
 * metodo que simula el sacar un huevo
 * @param unidades cantidad de huevos a sacar
 * @param dinero dinero con el que se pagara
 * @param sorpresa sorpresa que lleva el huevo
 * @throws Exception si las unidades son mayores que las que quedan de huevos,
 * no se tiene suficiente dinero, o si el dinero es negativo
 */
public void sacarHuevosSorpresas(int unidades, double dinero, String sorpresa) throws Exception{
   if (dinero <= 0) {
   	throw new Exception("Se necesita una cantidad de dinero positiva");
        }
   if (dinero <(unidades * getPrecio())) {
   	throw new Exception("No tiene suficiente dinero");
        }
   if (unidades<= 0){
        throw new Exception("Es necesario indicar una cantidad positiva de huevos sorpresa");
    }
    if( this.getUnidades()<unidades){
        throw new Exception("No hay suficientes huevos sorpresa en la tienda");
    }
    this.modificarUnidades(this.obtenerUnidades()-unidades);
}

/**
 * metodo que aumenta el precio de un huevo
 * @param aumento cantidad a aumentar
 * @throws Exception si la suma del precio actual mas el aumento es superior al
 * precio maximo
 */
public void aumentarPrecio(double aumento) throws Exception{
    if(aumento <= 0) {
        throw new Exception("El aumento debe ser positivo");
    }
    if( getPrecio_max()<getPrecio() + aumento ){
        throw new Exception("No se puede superar el precio máximo");
    }
        setPrecio(getPrecio() + aumento);
}
}