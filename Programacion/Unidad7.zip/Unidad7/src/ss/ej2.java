/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ss;

import java.util.Scanner;

/**
 *
 * @author matii
 */
public class ej2 {
    public static void main(String[] args) {
        int[][] mat1, mat2;
        int fil, col;
        Scanner teclado = new Scanner(System.in);
        
        
        System.out.println("Ingresa las filas de la primera matriz");
        fil = teclado.nextInt();
        System.out.println("Ingresa las columnas de la primera matriz");
        col = teclado.nextInt();
        mat1 = new int[fil][col];
    }
}
