package ejercicios;


public class Ejercicio04 {

    public static void main(String[] args) {
       
        
 
    }

}
