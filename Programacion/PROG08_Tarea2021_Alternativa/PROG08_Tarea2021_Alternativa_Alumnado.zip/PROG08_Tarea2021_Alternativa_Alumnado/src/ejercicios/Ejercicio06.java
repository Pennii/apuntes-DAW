package ejercicios;


public class Ejercicio06 {

    public static void main(String[] args) {

            
        
    }
}


class ComparadorProductosPorNombre  {

    
}



class ComparadorProductosPorCaducidad  {
    

}



class ComparadorProductosPorPrecio  {
    

}    
    
    
