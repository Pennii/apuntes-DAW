package ejercicios;

public class Ejercicio01 {
    
    
    public static void main(String[] args) {

    }
   
}
